---
name: Bug Report
about: Create a bug report for triage and support.
title: ''
labels: ''
assignees: ''

---

**Describe the bug**
<!-- Write what's happening under this line -->

**Source**
<!-- Optionally, provide a link to your source or put it in a codeblock -->

**Error**
<!-- Provide the error in a codeblock -->

**Versions (Must be completed):**
 - OS Ver: 
 - Java Version: `Change this to the output of java -version`
 - Library Version: `What version of discord-rpc are you using?`

**Additional info**
<!-- Any notes? -->
